<?php
  function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass="";
 $db = "todolist";
 $conn = mysqli_connect($dbhost, $dbuser,$dbpass,$db);
 if(!$conn)
 {
 die("Connect failed: %s\n". mysqli_connect_error());
 }
 else
 echo "Connected";
 return $conn;
 }
 

?>